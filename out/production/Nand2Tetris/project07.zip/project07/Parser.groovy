package project07

import project07.Constants.CommandType

class Parser {

    private File file = null
    private String currentCommand

    /**
     *
     * @param file
     */
    Parser(File inputFile) {
        this.file = inputFile
    }

    /**
     * setter
     * @param cmd
     */
    void setCurrentCommand(String cmd) {
        this.currentCommand = cmd
    }

    /**
     * getter
     * @return
     */
    CommandType getCommandType() {
        switch (currentCommand.split(' ')[0]) {
            case 'push'-> CommandType.C_PUSH
            case 'pop'-> CommandType.C_POP
            case 'add','sub','neg','eq','gt','lt','and','or','not'-> CommandType.C_ARITHMETIC
            default -> CommandType.C_NOTHING
        }
    }

    /**
     *
     * @return
     */
    String arg1() {
        currentCommand.split(' ')[1]
    }

    /**
     *
     * @return
     */
    int arg2() {
        currentCommand.split(' ')[2] as int
    }

    /* boolean hasMoreCommands() {
    }

    def advance() {
    } */
}